/*! Achordeon - MIT License

Copyright (c) 2017 Wolf Robben

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
!*/
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;

/*
 * How to:
 * Put "$(SolutionDir)HeaderLicensePrepend.exe $(SolutionDir)License.Template.json -a" in pre-build-event of your main project.
 * Place a file "License.Template.json" in your solution folder. Example for this file: see below.
 * Rebuild your project
 * To remove the license headers from all files, change the "-a" argument to "-r" and rebuild again.
 * 
 * Example template: (You have to remove the blanks in "/ *" and "* /" to use it... ;-) )
 
    {
	headers: [
		{
			hstart: "/ *!",
			hend: "!* /",
			text:  "/ *! Achordeon - MIT License

Copyright(c) 2017 Wolf Robben

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the \"Software\"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
!* /"

        }
	]
} 

*/

namespace HeaderLicensePrepend
{
    internal class Program
    {
        public enum Mode
        {
            Add,
            Remove
        }

        private static void Main(string[] Arguments)
        {
            if (Arguments.Length != 2)
                throw new Exception("Expected command line arguments: path to settings file, and -a or -r");
            var SettingsFile = Arguments[0];
            var ProcessMode = Arguments[1].ToLower() .Trim()== "-r" ? Mode.Remove : Mode.Add;
            if (!File.Exists(SettingsFile))
                throw new Exception($"Settings file '{SettingsFile}' not found");
            var fi = new FileInfo(SettingsFile);;
            var WorkingDirectoryName = fi.Directory?.FullName;
            if (string.IsNullOrWhiteSpace(WorkingDirectoryName))
                throw new Exception("Unable to determine working directory name");
            foreach (Dictionary<string, object> Setting in (IEnumerable) ((Dictionary<string, object>) new JavaScriptSerializer().Deserialize(File.ReadAllText(SettingsFile), typeof (object)))["headers"])
            {
                var HeaderStartSignature = Setting["hstart"].ToString();
                if (string.IsNullOrWhiteSpace(HeaderStartSignature))
                    throw new Exception("Header start signature cannot be empty");
                var HeaderEndSignature = Setting["hend"].ToString();
                if (string.IsNullOrWhiteSpace(HeaderEndSignature))
                    throw new Exception("Header end signature cannot be empty");
                var Header = Setting["text"].ToString();
                if (string.IsNullOrWhiteSpace(Header))
                    throw new Exception("Header text cannot be empty");

                var Files = Directory.GetFiles(WorkingDirectoryName, "*.*", SearchOption.AllDirectories).Where(a => IsValidFile(a));

                foreach (var FileName in Files)
                    ProcessFile(FileName, HeaderStartSignature, HeaderEndSignature, Header, ProcessMode);
            }
        }

        private static bool IsValidFile(string AFileName)
        {
            var Extension = new FileInfo(AFileName).Extension;
            if (!StringComparer.OrdinalIgnoreCase.Equals(Extension, ".cs"))
                return false;
            var LowerName = AFileName.ToLower();
            if (LowerName.EndsWith(".g.cs"))
                return false;
            if (LowerName.ToLower().EndsWith(".g.i.cs"))
                return false;
            if (LowerName.Contains("temporarygeneratedfile"))
                return false;
            return true;
        }

        private static void ProcessFile(string AFileName, string AHeaderStartSignature, string AHeaderEndSignature, string AHeader, Mode AMode)
        {
            var ResultLines = new List<string>();
            if (AMode == Mode.Add)
                ResultLines.AddRange(AHeader.Split(new[] { Environment.NewLine }, StringSplitOptions.None).ToList());

            var OriginalLines = File.ReadAllLines(AFileName);
            var CurrentlyInsideOfHeader = false;
            var IsFirstHeader = true;
            foreach (var Line in OriginalLines)
            {
                if (!IsFirstHeader)
                    ResultLines.Add(Line);
                else
                {
                    if (!CurrentlyInsideOfHeader && Line.StartsWith(AHeaderStartSignature))
                        CurrentlyInsideOfHeader = true;
                    if (CurrentlyInsideOfHeader && Line.StartsWith(AHeaderEndSignature))
                    {
                        IsFirstHeader = false;
                        CurrentlyInsideOfHeader = false;
                    }
                    else if (!CurrentlyInsideOfHeader)
                        ResultLines.Add(Line);
                }
            }
            if (!OriginalLines.SequenceEqual(ResultLines))
                File.WriteAllLines(AFileName, ResultLines.ToArray());
        }

    }
}
