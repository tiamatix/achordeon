/*! Achordeon - MIT License

Copyright (c) 2017 Wolf Robben

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
!*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileVer
{
    using System;
    using System.IO;
    using System.Diagnostics;
    using System.Reflection;

    namespace Version
    {
        class GetVersion
        {
            static void Main(string[] AArgs)
            {
                if (AArgs.Length == 0 || AArgs.Length > 1)
                       ShowUsage();

                var TargetPath = AArgs[0];

                TargetPath = Path.IsPathRooted(TargetPath)
                                    ? TargetPath
                                    : Path.Combine(Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName), TargetPath);

                if (!File.Exists(TargetPath))
                {
                    Console.WriteLine($"Does not exists: {TargetPath}");
                    ShowUsage();
                }

                var Assy = Assembly.LoadFrom(TargetPath);
                var VersionAttribute = (AssemblyInformationalVersionAttribute)Assy.GetCustomAttributes(typeof(AssemblyInformationalVersionAttribute), false).FirstOrDefault();
                var Version = VersionAttribute != null ? VersionAttribute.InformationalVersion : Assy.GetName().Version.ToString();

                Console.Write(Version);
            }

            static void ShowUsage()
            {
                Console.WriteLine("*** FileVer by Tiamatix ***");
                Console.WriteLine("Usage: FileVer.exe <path to target file>");
                Environment.Exit(-1);
            }
        }
    }
}
